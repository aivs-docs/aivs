package demo.aivoice.client.aivs.protocol.payload;

import com.google.gson.annotations.SerializedName;
import lombok.Builder;
import lombok.Data;

import java.util.List;

@Data
@Builder
public class RenderPlayerInfoPayload extends Payload {

    /**
     * Identifies the audioItem. This parameter should be used to correlate the provided visual
     * metadata with a Play directive.
     */
    @SerializedName("audioItemId")
    String audioItemId;
    /**
     * Identifies the template.
     */
    @SerializedName("content")
    Content content;
    @SerializedName("controls")
    List<Control> controls;

    @Builder
    public static class Content {

        /**
         * The title.
         * 歌曲名 / 音频名
         */
        @SerializedName("title")
        String title;
        /**
         * 演唱者 / 作者
         */
        @SerializedName("titleSubtext1")
        String titleSubtext1;
        /**
         *
         */
        @SerializedName("titleSubtext2")
        String titleSubtext2;
        /**
         * The first header text field.
         * 专辑名
         */
        @SerializedName("header")
        String header;
        @SerializedName("headerSubtext1")
        String headerSubtext1;
        /**
         * The stream duration in milliseconds.
         */
        @SerializedName("mediaLengthInMilliseconds")
        long mediaLengthInMilliseconds;
        /**
         * Artwork for provided audio item.
         */
        @SerializedName("art")
        ImageStructure art;
        /**
         * Contains information about the content provider.
         */
        @SerializedName("provider")
        Provider provider;
    }

    @Builder
    public static class Provider {

        /**
         * Content provider's name.
         */
        @SerializedName("name")
        String name;
        /**
         * Content provider's logo.
         */
        @SerializedName("logo")
        ImageStructure logo;
    }

    @Builder
    public static  class Control {

        /**
         * Identifies the control type. Accepted values: BUTTON, TOGGLE.
         */
        @SerializedName("type")
        String type;
        /**
         * The name of the control. All controls included in the array must be rendered. Accepted
         * values: PLAY_PAUSE, NEXT, PREVIOUS, SKIP_FORWARD, SKIP_BACKWARD, SHUFFLE, LOOP,
         * THUMBS_UP, THUMBS_DOWN.
         */
        @SerializedName("name")
        String name;
        /**
         * Informs the client if the control is clickable. The value is true when the control can be
         * clicked by the user.
         */
        @SerializedName("enabled")
        boolean enabled;
        /**
         * Indicates that a control should render in a selected state. For example, if a user has
         * favorited a song, when this song plays, the control that represents favorite will have a
         * selected value of true.
         */
        @SerializedName("selected")
        boolean selected;

    }
}

