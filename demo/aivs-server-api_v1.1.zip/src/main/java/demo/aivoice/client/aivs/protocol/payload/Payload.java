package demo.aivoice.client.aivs.protocol.payload;

import com.google.gson.JsonElement;
import demo.aivoice.client.Singleton;

public class Payload {

    public String toJson() {
        return Singleton.GSON.toJson(this);
    }
    public JsonElement toJsonTree(){
        return Singleton.GSON.toJsonTree(this);
    }
}
