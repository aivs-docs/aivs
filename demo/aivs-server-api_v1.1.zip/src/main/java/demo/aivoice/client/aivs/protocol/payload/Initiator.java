package demo.aivoice.client.aivs.protocol.payload;

import com.google.gson.annotations.SerializedName;
import lombok.Data;

@Data
public class Initiator {

    /**
     * Represents the action taken by a user to initiate an interaction with Alexa.
     *
     * Accepted values: PRESS_AND_HOLD, TAP, and WAKEWORD.
     *
     * If an initiator.type is provided in an ExpectSpeech directive, that string must be returned
     * as initiator.type in the following Recognize event.
     */
    @SerializedName("type")
    String type;
    /**
     * Includes information about the initiator
     */
    @SerializedName("payload")
    InitiatorPayload payload;

    @Data
    public static class InitiatorPayload {

        @SerializedName("wakeWordIndices")
        WakeWordIndices wakeWordIndices;
        /**
         * An opaque string. If present it must be sent back to Alexa in the following Recognize
         * event.
         */
        @SerializedName("token")
        String token;
    }

    @Data
    public static class WakeWordIndices {

        @SerializedName("startIndexInSamples")
        long startIndexInSamples;
        @SerializedName("endIndexInSamples")
        long endIndexInSamples;
    }
}
