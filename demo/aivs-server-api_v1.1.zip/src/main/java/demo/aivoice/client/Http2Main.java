package demo.aivoice.client;

import demo.aivoice.client.aivs.Constant;
import demo.aivoice.client.aivs.protocol.ResponseContent;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;

import java.util.List;
import java.util.UUID;

public class Http2Main {

    private static final Logger LOGGER = LoggerFactory.getLogger(Http2Main.class);

    public static void main(String[] args) throws Exception {

        String appId = AiVSClientConfig.INSTANCE.getAppId();
        String deviceId = AiVSClientConfig.INSTANCE.getDeviceId();
        String accessToken = AiVSClientConfig.INSTANCE.getAccessToken();

        AivsClient client = AivsHttp2Client.builder()
                .appId(appId)
                .deviceId(deviceId)
                .accessToken(accessToken)
                .host(Constant.HOST_PROD)
                .port(443)
                .build();
        String text = "北京今天天气怎么样";

        List<ResponseContent> responseContents = client
                .textChat(text, UUID.randomUUID().toString());

        int index = 0;
        for (ResponseContent responseContent : responseContents) {
            LOGGER.info(String.format("ResponseContent %d: %s", index++,
                    responseContent.toJson()));
        }
    }
}
