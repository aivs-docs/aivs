package demo.aivoice.client;

import com.google.gson.Gson;
import demo.aivoice.client.common.HttpRequestSender;
import org.apache.commons.lang3.concurrent.BasicThreadFactory;
import org.apache.http.conn.ssl.NoopHostnameVerifier;
import org.apache.http.impl.nio.client.CloseableHttpAsyncClient;
import org.apache.http.impl.nio.client.HttpAsyncClients;
import org.apache.http.ssl.SSLContexts;

import java.net.InetAddress;
import java.net.UnknownHostException;
import java.security.KeyManagementException;
import java.security.KeyStoreException;
import java.security.NoSuchAlgorithmException;
import java.util.concurrent.ExecutorService;
import java.util.concurrent.LinkedBlockingQueue;
import java.util.concurrent.ThreadPoolExecutor;
import java.util.concurrent.TimeUnit;
import javax.net.ssl.SSLContext;

public class Singleton {

    public static final CloseableHttpAsyncClient HTTP_CLIENT;

    static {
        try {
            HTTP_CLIENT = HttpAsyncClients.custom()
                    .setMaxConnTotal(1000)
                    .setMaxConnPerRoute(500)
                    .build();
            HTTP_CLIENT.start();
        } catch (Throwable e) {
            throw new RuntimeException(
                    "Fatal error! Failed on initializing CloseableHttpAsyncClient!", e);
        }
    }

    public static final CloseableHttpAsyncClient HTTPS_CLIENT;

    static {
        try {
            SSLContext sslContext = SSLContexts
                    .custom().loadTrustMaterial(null, (certificate, authType) -> true).build();
            HTTPS_CLIENT = HttpAsyncClients.custom()
                    .setMaxConnTotal(1000)
                    .setMaxConnPerRoute(500)
                    .setSSLHostnameVerifier(NoopHostnameVerifier.INSTANCE)
                    .setSSLContext(sslContext)
                    .build();
            HTTPS_CLIENT.start();
        } catch (NoSuchAlgorithmException | KeyManagementException | KeyStoreException e) {
            throw new RuntimeException("Fatal error! Failed on initializing SSLContexts!", e);
        }
    }

    public static final HttpRequestSender HTTP_REQUEST_SENDER;

    static {
        HTTP_REQUEST_SENDER = new HttpRequestSender();
    }

    public static final Gson GSON = new Gson();

    public static String HOST_NAME = "unknow";

    static {
        try {
            InetAddress addr = InetAddress.getLocalHost();
            HOST_NAME = addr.getHostName();
        } catch (UnknownHostException e) {
            e.printStackTrace();
        }
    }

    public static final int DEFAULT_CORE_POOL_SIZE = 6;
    public static final int DEFAULT_MAX_POOL_SIZE = 60;
    public static final int DEFAULT_MAX_QUEUE_SIZE = 6000;

    final public static ExecutorService THREAD_POOL = new ThreadPoolExecutor(
            DEFAULT_CORE_POOL_SIZE * 2, DEFAULT_MAX_POOL_SIZE * 2, 60,
            TimeUnit.SECONDS, new LinkedBlockingQueue<>(DEFAULT_MAX_QUEUE_SIZE * 2),
            new BasicThreadFactory.Builder().namingPattern("public-thread-pool-%d").daemon(true)
                    .build());
}
