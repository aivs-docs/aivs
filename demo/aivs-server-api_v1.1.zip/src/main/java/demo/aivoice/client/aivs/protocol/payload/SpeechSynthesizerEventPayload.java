package demo.aivoice.client.aivs.protocol.payload;

import com.google.gson.JsonElement;
import com.google.gson.annotations.SerializedName;
import demo.aivoice.client.Singleton;
import lombok.Getter;


/**
 * payload in event:
 *
 * SpeechSynthesizer-SpeechStarted
 *
 * SpeechSynthesizer-SpeechFinished event
 *
 * @author hanfeng
 */
@Getter
public class SpeechSynthesizerEventPayload extends Payload {

    /**
     * The opaque token provided by the Speak directive.
     */
    @SerializedName("token")
    String token;

    public static SpeechSynthesizerEventPayload fromJson(JsonElement json) {
        return Singleton.GSON.fromJson(json, SpeechSynthesizerEventPayload.class);
    }
}
