package demo.aivoice.client;

import demo.aivoice.client.aivs.Constant;
import demo.aivoice.client.aivs.protocol.Event;
import demo.aivoice.client.aivs.protocol.Header;
import demo.aivoice.client.aivs.protocol.HeaderName;
import demo.aivoice.client.aivs.protocol.Namespace;
import demo.aivoice.client.aivs.protocol.RequestContent;
import demo.aivoice.client.aivs.protocol.ResponseContent;
import demo.aivoice.client.aivs.protocol.payload.TextEventPayload;
import lombok.Builder;
import org.apache.commons.io.IOUtils;
import org.apache.http.HttpResponse;
import org.apache.http.HttpStatus;
import org.apache.http.client.config.RequestConfig;
import org.apache.http.client.methods.HttpPost;
import org.apache.http.client.utils.URIBuilder;
import static org.apache.http.entity.ContentType.APPLICATION_JSON;
import org.apache.http.entity.mime.MultipartEntityBuilder;
import org.apache.http.impl.nio.client.CloseableHttpAsyncClient;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;

import java.io.InputStream;
import java.net.URISyntaxException;
import java.nio.charset.StandardCharsets;
import java.util.List;
import java.util.UUID;
import java.util.concurrent.Future;

/**
 * AiVS Http1.1 Client based on apache.httpcomponents
 *
 */
@Builder
public class AivsHttp1_1Client extends AivsClient {

    private static final Logger LOGGER = LoggerFactory.getLogger(AivsHttp1_1Client.class);

    private String host;
    private int port;
    @Builder.Default
    private int timeout = 5000;

    private String appId;
    private String deviceId;
    private String accessToken;

    @Override
    public List<ResponseContent> textChat(String text, String requestId)
            throws Exception {

        HttpPost httpPost = buildHttpPost(Constant.EVENT_PATH);

        // build header
        /*
         * authorization format:
         * d~appid~deviceid~token
         */
        String authorization = String.format("d~%s~%s~%s",
                appId, deviceId, accessToken);
        httpPost.setHeader("authorization", authorization);

        // build multi-part body
        Header header = Header.builder()
                .dialogRequestId(UUID.randomUUID().toString())
                .messageId(UUID.randomUUID().toString())
                .namespace(Namespace.TextRecognizer.name())
                .name(HeaderName.TextRecognize.name())
                .build();

        TextEventPayload payload = new TextEventPayload();
        payload.setText(text);
        payload.setLongitude(113.62);
        payload.setLatitude(34.75);

        Event event = Event.builder()
                .header(header)
                .payload(payload.toJsonTree())
                .build();

        // build RequestContent
        RequestContent requestContent = new RequestContent();
        requestContent.setEvent(event);

        MultipartEntityBuilder entityBuilder = MultipartEntityBuilder.create();
        entityBuilder.addTextBody("metadata", requestContent.toJson(), APPLICATION_JSON);

        httpPost.setEntity(entityBuilder.build());

        // execute request
        CloseableHttpAsyncClient httpsClient = Singleton.HTTPS_CLIENT;
        long startTime = System.currentTimeMillis();
        Future<HttpResponse> future = httpsClient.execute(httpPost, null);
        HttpResponse httpResponse = future.get();

        String responseStr = buildResponse(httpResponse, requestId, startTime);

        return buildResponseContents(responseStr);
    }

    private HttpPost buildHttpPost(String path) throws URISyntaxException {
        HttpPost httpPost;
        URIBuilder uri = new URIBuilder();

        uri.setScheme("https");
        uri.setHost(host);
        uri.setPath(path);
        uri.setPort(port);

        httpPost = new HttpPost(uri.build());

        httpPost.setConfig(RequestConfig.custom()
                .setConnectTimeout(timeout)
                .setSocketTimeout(timeout)
                .setConnectionRequestTimeout(timeout)
                .build());
        return httpPost;
    }

    private String buildResponse(HttpResponse httpResponse, String requestId, long startTime)
            throws Exception {
        if (httpResponse == null || httpResponse.getStatusLine() == null) {
            String errMsg = String.format("get null response from. requestId=%s", requestId);
            LOGGER.error(errMsg);
            throw new Exception(errMsg);
        }
        if (httpResponse.getStatusLine().getStatusCode() != HttpStatus.SC_OK) {
            String errMsg = String.format("get error status code. code=%d, reason=%s, requestId=%s",
                    httpResponse.getStatusLine().getStatusCode(),
                    httpResponse.getStatusLine().getReasonPhrase(), requestId);
            LOGGER.error(errMsg);

            if (httpResponse.getEntity() != null) {
                try (InputStream inputStream = httpResponse.getEntity().getContent()) {
                    if (inputStream != null) {
                        String response = IOUtils.toString(inputStream, StandardCharsets.UTF_8);
                        LOGGER.error(response);
                    }
                }
            }
            throw new Exception(errMsg);
        }
        LOGGER.debug("parsing response...");
        try (InputStream inputStream = httpResponse.getEntity().getContent()) {
            String response = IOUtils.toString(inputStream, StandardCharsets.UTF_8);
            LOGGER.info(
                    String.format("get response fromm. spend time=%d ms, response=%s, requestId=%s",
                            System.currentTimeMillis() - startTime,
                            response, requestId));
            LOGGER.info(response);
            return response;
        }
    }

}
