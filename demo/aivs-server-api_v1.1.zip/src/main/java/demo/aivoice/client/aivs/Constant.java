package demo.aivoice.client.aivs;

public interface Constant {
    String HOST_PROD = "aivs-stag.api.xiaomi.net";
    String EVENT_PATH = "/v20160207/events";
    String DIRECTIVE_PATH = "/v20160207/directives";
}
