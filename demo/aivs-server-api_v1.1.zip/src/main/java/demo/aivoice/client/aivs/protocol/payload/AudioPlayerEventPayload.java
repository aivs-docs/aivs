package demo.aivoice.client.aivs.protocol.payload;

import com.google.gson.JsonElement;
import com.google.gson.JsonObject;
import com.google.gson.annotations.SerializedName;
import demo.aivoice.client.Singleton;
import lombok.Data;

/**
 * payload in AudioPlayer event
 *
 * An empty payload must be sent in PlaybackQueueCleared event.
 *
 * https://developer.amazon.com/zh/docs/alexa-voice-service/audioplayer.html
 *
 */
@Data
public class AudioPlayerEventPayload extends Payload {

    /**
     * An opaque token provided by the Play directive.
     */
    @SerializedName("token")
    String token;

    /**
     * Identifies a track's current offset in milliseconds. The value sent must be equal to or
     * greater than zero. Negative values are not accepted.	long
     */
    @SerializedName("offsetInMilliseconds")
    long offsetInMilliseconds;

    // fields for stutter event
    /**
     * Identifies the duration of a stutter in milliseconds.
     */
    @SerializedName("stutterDurationInMilliseconds")
    long stutterDurationInMilliseconds;

    // fields for failed event

    @SerializedName("currentPlaybackState")
    PlaybackState currentPlaybackState;

    @SerializedName("error")
    PlaybackError error;

    // fields for metadata event
    /**
     * Contains key/value pairs associated with the metadata received.
     */
    @SerializedName("metadata")
    JsonObject metadata;

    private class PlaybackState {

        /**
         * An opaque token provided by the Play directive.
         */
        @SerializedName("token")
        String token;

        /**
         * Identifies a track's current offset in milliseconds. The value sent must be equal to or
         * greater than zero. Negative values are not accepted.	long
         */
        @SerializedName("offsetInMilliseconds")
        long offsetInMilliseconds;

        /**
         * Identifies the player state.
         *
         * Accepted values: PLAYING, STOPPED, PAUSED, FINISHED, BUFFER_UNDERRUN, or IDLE.
         */
        @SerializedName("playerActivity")
        String playerActivity;
    }

    private class PlaybackError {

        /**
         * Identifies the specific type of error. The table below provides details for each error
         * type.
         */
        @SerializedName("type")
        String type;

        /**
         * A description of the error the device has encountered. This is used for logging purposes
         * only. For HTTP related errors, the error message should contain the HTTP error response
         * body if present.
         */
        @SerializedName("message")
        String message;
    }


    public static AudioPlayerEventPayload fromJson(JsonElement json) {
        return Singleton.GSON.fromJson(json, AudioPlayerEventPayload.class);
    }
}
