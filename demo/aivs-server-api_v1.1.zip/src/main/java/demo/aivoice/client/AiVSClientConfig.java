package demo.aivoice.client;

import com.typesafe.config.Config;
import com.typesafe.config.ConfigFactory;
import lombok.Getter;

@Getter
public class AiVSClientConfig {

    private static final String DEFAULT_CONFIG_PATH = "config/aivsclient";
    private static final String CONFIG_NAMESPACE = "com.xiaomi.aivoice.aivsclient";
    private static final String DEPLOY_ENVIRONMENT = "default";

    private final String appId;
    private final String deviceId;
    private final String accessToken;

    public static final AiVSClientConfig INSTANCE = new AiVSClientConfig();

    private AiVSClientConfig(){
        String path = String.format("%s.%s",CONFIG_NAMESPACE, DEPLOY_ENVIRONMENT);
        Config conf = ConfigFactory.load(DEFAULT_CONFIG_PATH).getConfig(path);
        appId = conf.getString("appId");
        deviceId = conf.getString("deviceId");
        accessToken = conf.getString("accessToken");
    }
}
