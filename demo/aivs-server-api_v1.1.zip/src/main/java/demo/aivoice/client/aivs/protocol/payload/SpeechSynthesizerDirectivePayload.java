package demo.aivoice.client.aivs.protocol.payload;

import com.google.gson.JsonElement;
import com.google.gson.annotations.SerializedName;
import demo.aivoice.client.Singleton;
import lombok.Builder;
import lombok.Data;


/**
 * payload in SpeechSynthesizer-Speak directive
 *
 * @author hanfeng
 */
@Builder
@Data
public class SpeechSynthesizerDirectivePayload extends Payload {

    /**
     * A unique identifier for audio content. The URL always follows the prefix cid:.
     *
     * Example: cid:{{STRING}}
     */
    @SerializedName("url")
    String url;
    /**
     * Provides the format of returned audio.
     *
     * Accepted value: "AUDIO_MPEG"
     */
    @SerializedName("format")
    String format;
    /**
     * An opaque token that represents the current text-to-speech (TTS) object.
     */
    @SerializedName("token")
    String token;

    /**
     * The text of audio
     */
    @SerializedName("text")
    String text;

    public static SpeechSynthesizerDirectivePayload fromJsonTree(JsonElement jsonElement) {
        return Singleton.GSON.fromJson(jsonElement, SpeechSynthesizerDirectivePayload.class);
    }
}
