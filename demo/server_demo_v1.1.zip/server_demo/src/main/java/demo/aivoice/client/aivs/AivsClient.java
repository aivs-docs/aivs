package demo.aivoice.client.aivs;

import demo.aivoice.client.aivs.protocol.ResponseContent;
import org.apache.commons.io.IOUtils;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;

import java.io.IOException;
import java.nio.charset.StandardCharsets;
import java.util.LinkedList;
import java.util.List;
import javax.mail.BodyPart;
import javax.mail.MessagingException;
import javax.mail.internet.MimeMultipart;
import javax.mail.util.ByteArrayDataSource;

public abstract class AivsClient {

    private static final Logger LOGGER = LoggerFactory.getLogger(AivsHttp2Client.class);

    abstract public List<ResponseContent> textChat(String text, String requestId, double longitude, double latitude)
            throws Exception;
    abstract public List<ResponseContent> textChat(String text, String requestId, double longitude, double latitude, String authType)
            throws Exception;

    protected List<ResponseContent> buildResponseContents(String responseStr)
            throws IOException, MessagingException {
        List<ResponseContent> ret = new LinkedList<>();

        ByteArrayDataSource datasource = new ByteArrayDataSource(responseStr,
                "multipart/form-data");
        MimeMultipart multipart = new MimeMultipart(datasource);

        int count = multipart.getCount();
        LOGGER.info(count + " parts received.");
        for (int i = 0; i < count; i++) {
            BodyPart bodyPart = multipart.getBodyPart(i);
            if (bodyPart.isMimeType("application/json")) {
                LOGGER.info("Receive: " + bodyPart.getContentType());
                String body = IOUtils.toString(bodyPart.getInputStream(), StandardCharsets.UTF_8);
                LOGGER.info("Body:" + body);
                ret.add(ResponseContent.fromJson(body));

            } else if (bodyPart.isMimeType("application/octet-stream")) {
                LOGGER.info("Receive: " + bodyPart.getContentType());

            } else {
                LOGGER.error(String.format("not supported contentType=%s, body=%s",
                        bodyPart.getContentType(),
                        IOUtils.toString(bodyPart.getInputStream(), StandardCharsets.UTF_8)));
            }
        }
        return ret;
    }
}
