package demo.aivoice.client.aivs.protocol.payload;

public enum PlayBehavior {
    REPLACE_ALL,
    ENQUEUE,
    REPLACE_ENQUEUED
}
