package demo.aivoice.client.aivs.protocol;

public enum Namespace {
    SpeechRecognizer,
    SpeechSynthesizer,
    AudioPlayer,
    TemplateRuntime,
    TextRecognizer,
}
