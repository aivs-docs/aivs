package demo.aivoice.client;

import com.google.gson.JsonObject;
import demo.aivoice.client.aivs.AivsClient;
import demo.aivoice.client.aivs.AivsClientConfig;
import demo.aivoice.client.aivs.AivsHttp1_1Client;
import demo.aivoice.client.aivs.Constant;
import demo.aivoice.client.aivs.protocol.ResponseContent;
import demo.aivoice.client.utils.DeviceOAuthUtil;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;

import java.util.List;
import java.util.UUID;

public class DeviceOAuthMain {
    private static final Logger LOGGER = LoggerFactory.getLogger(DeviceOAuthMain.class);

    public static void main(String args[]) throws Exception{
        String deviceID = "8ac87cf7e5df4a91af5c89ab5d89853a";
        JsonObject scopeData = new JsonObject();
        scopeData.addProperty("d", deviceID);
        String state = DeviceOAuthUtil.getState(scopeData.toString());
        String scope_data = DeviceOAuthUtil.getBase64ScopeData(deviceID, AivsClientConfig.INSTANCE.getClientId());
        System.out.println(String.format("state=%s", state));
        System.out.println(String.format("scope_data=%s", scope_data));

        AivsClient client = AivsHttp1_1Client.builder()
                .appId(AivsClientConfig.INSTANCE.getClientId())
                .deviceId(deviceID)
                //将通过"设备OAuth授权流程"获取的token，填入该处
                .token("V3_eYwt_EoavwbYR1Ae_X3MlFd7IY_AOw7vhI_eXfLrlZfQOTYHm8vWcImHq6ulhq9oqJldQUU0ooCNpAATBb1piHbwxuuiGthi6gNvQGkSYkSklNogHxJ1cM9jSNA2FmCAGwBW8EuulFPiC-hwj-_uFOD-1-H12bBK3fEzQWddxTHLFy5oxJps4buEd6mjT52z")
                .host(Constant.HOST_PROD)
                .port(443)
                .build();

        String text = "播放一条新闻";
        List<ResponseContent> responseContents = client
                .textChat(text, UUID.randomUUID().toString(), 113.62, 34.75, Constant.DEVICE_OAUTH);

        int index = 0;
        for (ResponseContent responseContent : responseContents) {
            LOGGER.info(String.format("ResponseContent %d: %s", index++,
                    responseContent.toJson()));
        }
    }
}