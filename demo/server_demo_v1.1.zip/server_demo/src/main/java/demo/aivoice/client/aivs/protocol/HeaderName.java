package demo.aivoice.client.aivs.protocol;

public enum HeaderName {
    // SpeechRecognizer
    /**
     * This directive instructs your client to stop capturing a user’s speech after AVS has
     * identified the user’s intent or when end of speech is detected. When this directive is
     * received, your client must immediately close the microphone and stop listening for the user’s
     * speech.
     */
    StopCapture,
    /**
     * ExpectSpeech is sent when Alexa requires additional information to fulfill a user's request.
     * It instructs your client to open the microphone and begin streaming user speech. If the
     * microphone is not opened within the specified timeout window, an ExpectSpeechTimedOut event
     * must be sent from your client to AVS.
     *
     * During a multi-turn interaction with Alexa, your device will receive at least one
     * ExpectSpeech directive instructing your client to start listening for user speech. If
     * present, the initiator object included in the payload of the ExpectSpeech directive must be
     * passed back to Alexa as the initiator object in the following Recognize event. If initiator
     * is absent from the payload, the following Recognize event should not include initiator.
     *
     * For information on the rules that govern audio prioritization, please review the Interaction
     * Model.
     */
    ExpectSpeech,
    /**
     * The Recognize event is used to send user speech to AVS and translate that speech into one or
     * more directives. This event must be sent as a multipart message: the first part a
     * JSON-formatted object, the second, binary audio captured by the product's microphone. We
     * encourage streaming (chunking) captured audio to the Alexa Voice Service to reduce latency;
     * the stream should contain 10ms of captured audio per chunk (320 bytes).
     *
     * After an interaction with Alexa is initiated, the microphone must remain open until:
     *
     * A StopCapture directive is received.
     *
     * The stream is closed by the Alexa service.
     *
     * The user manually closes the microphone. For example, a press and hold implementation.
     */
    Recognize,
    /**
     * This event must be sent to AVS if an ExpectSpeech directive was received, but was not
     * satisfied within the specified timeout window.
     */
    ExpectSpeechTimedOut,

    // SpeechSynthesizer
    /**
     * This directive is sent from AVS to your client any time a speech response from Alexa is
     * required. In most cases, the Speak directive is sent in response to a user request, such as a
     * Recognize event. However, a Speak directive may also be sent to your client to preface an
     * action that will be taken. For instance, when a user makes a request to set a timer, in
     * addition to receiving a SetAlert directive that instructs the client to set an alarm, the
     * client also receives a Speak directive which notifies the user that the timer was
     * successfully set.
     *
     * This directive is sent to your client as a multipart message: one part a JSON-formatted
     * directive and one binary audio attachment.
     */
    Speak,
    /**
     * The SpeechStarted event should be sent to AVS after your client processes the Speak directive
     * and begins playback of synthesized speech.
     */
    SpeechStarted,
    /**
     * The SpeechFinished event must be sent after your client processes a Speak directive and Alexa
     * TTS is fully rendered to the user. If playback is not finished, for example a user interrupts
     * Alexa TTS with "Alexa, stop", then SpeechFinished is not sent.
     */
    SpeechFinished,

    // AudioPlayer
    /**
     * The Play directive is sent to your client to initiate audio playback. It is a multipart
     * message comprised of a JSON directive, and up to one audio stream or binary audio
     * attachment.
     */
    Play,
    /**
     * The Stop directive is sent to your client to stop playback of an audio stream. Your client
     * may receive a Stop directive as the result of a voice request, a physical button press or GUI
     * affordance.
     */
    Stop,
    /**
     * The ClearQueue directive is sent from AVS to your client to clear the playback queue. The
     * ClearQueue directive has two behaviors: CLEAR_ENQUEUED, which clears the queue and continues
     * to play the currently playing stream; and CLEAR_ALL, which clears the entire playback queue
     * and stops the currently playing stream (if applicable).
     */
    ClearQueue,
    /**
     * The PlaybackStarted event must be sent to AVS after your client processes a Play directive
     * and begins playback of the associated audio stream.
     */
    PlaybackStarted,
    /**
     * The PlaybackStopped event must be sent to AVS when your client receives one of the following
     * directives and stops playback of an audio stream:
     *
     * A Stop directive
     *
     * A Play directive with a playBehavior of REPLACE_ALL
     *
     * A ClearQueue directive with a clearBehavior of CLEAR_ALL
     */
    PlaybackStopped,
    /**
     * The PlaybackNearlyFinished event must be sent when your client is ready to buffer/download
     * the next stream in your playback queue. Your client must ensure that this event is only sent
     * following a PlaybackStarted event for the currently playing stream. Alexa will respond to
     * this event with one of the following:
     *
     * A Play directive containing the next stream
     *
     * An HTTP 204 response code
     */
    PlaybackNearlyFinished,
    /**
     * The ProgressReportDelayElapsed event must be sent to AVS if progressReportDelayInMilliseconds
     * is present in the Play directive. The event must be sent once at the specified interval from
     * the start of the stream (not from the offsetInMilliseconds).
     */
    ProgressReportDelayElapsed,
    /**
     * The ProgressReportIntervalElapsed event must be sent to AVS if progressReportIntervalInMilliseconds
     * is present in the Play directive. The event must be sent periodically at the specified
     * interval from the start of the stream (not from the offsetInMilliseconds).
     */
    ProgressReportIntervalElapsed,
    /**
     * The PlaybackStutterStarted event must be sent to AVS, following a PlaybackStarted event, when
     * the client's AudioPlayer component is being fed data slower than it is being read. The
     * component must transition to the buffer_underrun state once this event has been sent and
     * remain in this state until the buffer is full enough to resume playback.
     */
    PlaybackStutterStarted,
    /**
     * The PlaybackStutterFinished event must be sent to AVS when the buffer is full enough to
     * resume playback of a stream. AVS doesn't expect a subsequent PlaybackStarted event when audio
     * playback resumes.
     */
    PlaybackStutterFinished,
    /**
     * The PlaybackFinished event must be sent to AVS when your client finishes playback of a
     * stream.
     */
    PlaybackFinished,
    /**
     * The PlaybackFailed event must be sent to AVS whenever your client encounters an error while
     * attempting to play a stream. It is possible for the currentPlaybackToken to be different from
     * the token in the payload in cases where a stream is playing and the next stream fails to
     * buffer.
     */
    PlaybackFailed,
    /**
     * The PlaybackPaused event must be sent when your client temporarily pauses audio on the
     * Content channel to accommodate a higher priority input/output. Playback must resume when the
     * prioritized activity completes; at which point your client must send a PlaybackResumed event.
     * For more information on prioritizing audio input/outputs, see Interaction Model.
     */
    PlaybackPaused,
    /**
     * The PlaybackResumed event must be sent to AVS when playback resumes following a
     * PlaybackPaused event (when playback is temporarily paused on the Content channel to
     * accommodate a higher priority input/output). For more information on prioritizing audio
     * input/outputs, see Interaction Model.
     */
    PlaybackResumed,
    /**
     * The PlaybackQueueCleared event must be sent to AVS after your client handles a ClearQueue
     * directive.
     */
    PlaybackQueueCleared,
    /**
     * If metadata is available for an audio stream that your client receives and starts playing:
     * your client should take the key/value pairs received as raw data and translate those pairs
     * into a JSON object. In this JSON object, strings and numbers should be represented as JSON
     * strings, and booleans should be represented as JSON booleans. Your client should filter out
     * any tags containing binary data. For example, your client should not send the image, image
     * preview, attachment, or application data tags to AVS.
     */
    StreamMetadataExtracted,
    // System
    /**
     * The SynchronizeState event must be sent to update AVS on the state of all product components
     * when a new connection is established.
     */
    SynchronizeState,
    /**
     * This event must be sent after an hour of inactivity, and every hour after that until a user
     * action is taken. This provides Alexa with the duration since the last user activity was
     * detected. A user activity is defined as an action that confirms a user is in the presence of
     * the product, such as interacting with on-product buttons, speaking with Alexa, or using a GUI
     * affordance. After a user activity is detected, the timer used to track inactivity must be
     * reset to 0.
     */
    UserInactivityReport,
    /**
     * The ResetUserInactivity directive is sent to your client to reset the inactivity timer used
     * by UserInactivityReport. For example, a user interaction on the Amazon Alexa app would
     * trigger this
     */
    ResetUserInactivity,
    /**
     * The SetEndpoint directive instructs a client to change endpoints when the following
     * conditions are met:
     *
     * A user's country/region settings are not supported by the endpoint they have connected to.
     * For example, if a user's current country/region is set to the United Kingdom (UK) in Manage
     * Your Content and Devices and the client connects to the United States (US) endpoint, a
     * SetEndpoint directive will be sent instructing the client to connect to the endpoint that
     * supports the UK. A user changes their country/region settings (or address). For example, if a
     * user connected to the US endpoint changes their current country/region from the US to the UK,
     * a SetEndpoint directive will be sent instructing the client to connect to the endpoint that
     * supports the UK.
     */
    SetEndpoint,
    /**
     * This event communicates your product's software information to Alexa, such as firmware
     * version. It must be sent in these scenarios:
     *
     * For products with persistent memory, the event must be sent on the product's initial boot and
     * whenever the firmware version is updated. For products without persistent memory, the event
     * must be sent on each boot/reboot. When a ReportSoftwareInfo directive is received. If the
     * event is successfully processed, the product will receive a 204 HTTP status code with an
     * empty body. If the event is not processed the product will receive a 500 HTTP status code and
     * an Exception Message from Alexa.
     */
    SoftwareInfo,
    /**
     * This directive instructs your product to report current software information to Alexa using
     * the SoftwareInfo event.
     */
    ReportSoftwareInfo,
    /**
     * Your client must send this event when it is unable to execute a directive from AVS.
     */
    ExceptionEncountered,
    /**
     * This directive instructs your client to clear all Login With Amazon (LWA) authorization
     * tokens stored on a device.
     */
    RevokeAuthorization,

    // TemplateRuntime
    /**
     * The Render directive instructs your client to display visual metadata associated with a
     * user's request. For example, when a user asks Alexa, "Who is Usain Bolt?". In addition to
     * sending a   Speak directive, AVS will send a Render directive with visual metadata that your
     * client will bind to a template and render for the end user.
     */
    RenderTemplate,
    /**
     * The RenderPlayerInfo directive instructs your client to display visual metadata associated
     * with a media item, such as a song or playlist. In addition to sending a   Play directive, AVS
     * will send a RenderPlayerInfo directive with visual metadata specific to an audio content
     * provider that your client will bind to a template and render for the end user.
     */
    RenderPlayerInfo,

    // TextRecognizer
    /**
     * The TextRecognize event is used to send text to AVS and translate that speech into one or
     * more directives.
     *
     * Extension to AVS event.
     */
    TextRecognize,
    /**
     * The TextToSpeech event is used to send text to AVS and translate that into speech.
     *
     * Extension to AVS event.
     */
    TextToSpeech
}
