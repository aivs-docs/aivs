package demo.aivoice.client.common;

import lombok.Builder;
import lombok.Getter;
import org.apache.commons.io.IOUtils;
import org.apache.http.HttpResponse;
import org.apache.http.HttpStatus;
import org.apache.http.util.EntityUtils;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;

import java.io.IOException;
import java.io.InputStream;
import java.nio.charset.StandardCharsets;
import java.util.Optional;

public class HttpHelper {

    static final Logger LOGGER = LoggerFactory.getLogger(HttpHelper.class);

    public static void checkHttpResponse(HttpResponse httpResponse, String serviceId,
            String requestId) throws Exception {
        if (httpResponse == null || httpResponse.getStatusLine() == null) {
            String errMsg = String
                    .format("get null response. service=%s, requestId=%s", serviceId, requestId);
            if (httpResponse != null && httpResponse.getEntity() != null) {
                EntityUtils.consume(httpResponse.getEntity());
            }
            throw new Exception(errMsg);
        }
        if (httpResponse.getStatusLine().getStatusCode() != HttpStatus.SC_OK) {
            String response = null;
            if (httpResponse.getEntity() != null) {
                try (InputStream inputStream = httpResponse.getEntity().getContent()) {
                    response = IOUtils.toString(inputStream, StandardCharsets.UTF_8);
                }
            }
            String errMsg = String
                    .format("get failure. status code=%d, reason=%s, response=%s, service=%s, requestId=%s",
                            httpResponse.getStatusLine().getStatusCode(),
                            httpResponse.getStatusLine().getReasonPhrase(),
                            response, serviceId, requestId);
            LOGGER.error(errMsg);

            throw new Exception(errMsg);
        }
    }

    @Builder
    @Getter
    public static class SimpleHttpResponse {

        int statusCode;
        String response;
    }

    public static SimpleHttpResponse buildSimpleResponse(HttpResponse httpResponse,
            String serviceId, String requestId) throws Exception {
        if (httpResponse == null || httpResponse.getStatusLine() == null) {
            String errMsg = String.format("get null response. service=%s, requestId=%s",
                    serviceId, requestId);
            Optional.ofNullable(httpResponse)
                    .ifPresent(hr -> Optional.ofNullable(hr.getEntity())
                            .ifPresent(entity -> {
                                try {
                                    EntityUtils.consume(entity);
                                } catch (IOException e) {
                                    LOGGER.error("Consume entity failed: ", e);
                                }
                            }));
            throw new Exception(errMsg);
        }

        String response = null;
        LOGGER.debug("parsing response...");
        if (httpResponse.getEntity() != null) {
            try (InputStream inputStream = httpResponse.getEntity().getContent()) {
                response = IOUtils.toString(inputStream, StandardCharsets.UTF_8);
            }
        }
        if (httpResponse.getStatusLine().getStatusCode() == HttpStatus.SC_OK) {
            LOGGER.info(String.format("Got response. response=%s, service=%s, requestId=%s",
                    response, serviceId, requestId));
        } else {
            LOGGER.error(String.format(
                    "Got failure. status code=%d, reason=%s, response=%s, service=%s, requestId=%s",
                    httpResponse.getStatusLine().getStatusCode(),
                    httpResponse.getStatusLine().getReasonPhrase(),
                    response, serviceId, requestId));
        }
        return SimpleHttpResponse.builder()
                .statusCode(httpResponse.getStatusLine().getStatusCode())
                .response(response)
                .build();
    }
}
