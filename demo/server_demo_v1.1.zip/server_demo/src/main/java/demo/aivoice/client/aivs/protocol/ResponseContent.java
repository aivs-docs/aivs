package demo.aivoice.client.aivs.protocol;

import com.google.gson.annotations.SerializedName;
import demo.aivoice.client.utils.Singleton;

public class ResponseContent {


    @SerializedName("directive")
    Directive directive;

    public ResponseContent(Directive directive) {
        this.directive = directive;
    }

    public String toJson() {
        return Singleton.GSON.toJson(this);
    }

    public static ResponseContent fromJson(String json) {
        return Singleton.GSON.fromJson(json, ResponseContent.class);
    }
}
