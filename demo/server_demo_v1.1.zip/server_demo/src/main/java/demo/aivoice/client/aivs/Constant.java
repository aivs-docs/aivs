package demo.aivoice.client.aivs;

public interface Constant {
    String HOST_PROD = "aivs.api.xiaomi.net";
    String EVENT_PATH = "/v20160207/events";
    String DIRECTIVE_PATH = "/v20160207/directives";

    String APP_ANONYMOUS = "app_anonymous";
    String DEVICE_OAUTH = "device_oauth";
}
