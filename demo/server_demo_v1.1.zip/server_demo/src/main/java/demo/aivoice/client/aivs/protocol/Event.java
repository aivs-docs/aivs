package demo.aivoice.client.aivs.protocol;

import com.google.gson.JsonElement;
import com.google.gson.annotations.SerializedName;
import lombok.Builder;
import lombok.Data;

@Data
@Builder
public class Event {
    @SerializedName("header")
    Header header;
    @SerializedName("payload")
    JsonElement payload;
}
