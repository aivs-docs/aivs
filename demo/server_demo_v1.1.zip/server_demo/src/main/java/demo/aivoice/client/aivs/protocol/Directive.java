package demo.aivoice.client.aivs.protocol;

import com.google.gson.JsonElement;
import com.google.gson.annotations.SerializedName;
import demo.aivoice.client.utils.Singleton;
import lombok.Builder;
import lombok.Data;

@Builder
@Data
public class Directive {

    @SerializedName("header")
    Header header;
    @SerializedName("payload")
    JsonElement payload;

    public String toJson() {
        return Singleton.GSON.toJson(this);
    }

    public static Directive fromJson(String json) {
        return Singleton.GSON.fromJson(json, Directive.class);
    }
}
