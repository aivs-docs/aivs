package demo.aivoice.client.aivs.protocol.payload;

import com.google.gson.annotations.SerializedName;
import lombok.Data;

/**
 * payload in directive:
 *
 * SpeechRecognizer-StopCapture
 *
 * SpeechRecognizer-ExpectSpeech
 *
 */
@Data
public class SpeechRecognizerDirectivePayload extends Payload {

    /**
     * Specifies, in milliseconds, how long your client should wait for the microphone to open and
     * begin streaming user speech to AVS. If the microphone is not opened within the specified
     * timeout window, then the ExpectSpeechTimedOut event must be sent. The primary use case for
     * this behavior is a PRESS_AND_HOLD implementation.
     */
    @SerializedName("timeoutInMilliseconds")
    long timeoutInMilliseconds;

    /**
     * Contains information about the interaction. If present it must be sent back to Alexa in the
     * following Recognize event.
     */
    @SerializedName("Initiator")
    Initiator initiator;
}
