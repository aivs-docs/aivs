package demo.aivoice.client.aivs.protocol;

import com.google.gson.annotations.SerializedName;
import lombok.Builder;
import lombok.Data;

@Builder
@Data
public class AnonymousResponse {

    @SerializedName("code")
    int code;
    @SerializedName("description")
    String description;
    @SerializedName("result")
    Result result;

    @Builder
    @Data
    public static class Result {

        @SerializedName("access_token")
        String accessToken;
        @SerializedName("refresh_token")
        String refreshToken;
        @SerializedName("expires_in")
        int expiresIn;

    }
}
