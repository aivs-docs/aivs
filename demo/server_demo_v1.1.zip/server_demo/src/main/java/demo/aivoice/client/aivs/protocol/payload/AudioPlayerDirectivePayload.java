package demo.aivoice.client.aivs.protocol.payload;

import com.google.gson.annotations.SerializedName;
import lombok.Builder;
import lombok.Data;

//{
//    "directive": {
//        "header": {
//            "namespace": "AudioPlayer",
//            "name": "Play",
//            "messageId": "{{STRING}}",
//            "dialogRequestId": "{{STRING}}"
//        },
//        "payload": {
//            "playBehavior": "{{STRING}}",
//            "audioItem": {
//                "audioItemId": "{{STRING}}",
//                "stream": {
//                    "url": "{{STRING}}",
//                    "streamFormat": "AUDIO_MPEG"
//                    "offsetInMilliseconds": {{LONG}},
//                    "expiryTime": "{{STRING}}",
//                    "progressReport": {
//                        "progressReportDelayInMilliseconds": {{LONG}},
//                        "progressReportIntervalInMilliseconds": {{LONG}}
//                    },
//                    "token": "{{STRING}}",
//                    "expectedPreviousToken": "{{STRING}}"
//                }
//            }
//        }
//    }
//}

//{
//    "directive": {
//        "header": {
//            "namespace": "AudioPlayer",
//            "name": "Stop",
//            "messageId": "{{STRING}}",
//            "dialogRequestId": "{{STRING}}"
//        },
//        "payload": {
//        }
//    }
//}

//{
//    "directive": {
//        "header": {
//            "namespace": "AudioPlayer",
//            "name": "ClearQueue",
//            "messageId": "{{STRING}}",
//            "dialogRequestId": "{{STRING}}"
//        },
//        "payload": {
//            "clearBehavior": "{{STRING}}"
//        }
//    }
//}

/**
 * payload in AudioPlayer-Play directive AudioPlayer-Stop directive
 *
 * https://developer.amazon.com/zh/docs/alexa-voice-service/audioplayer.html
 *
 * @author hanfeng
 */
@Builder
@Data
public class AudioPlayerDirectivePayload extends Payload {

    /**
     * Provides playback hints.
     *
     * Accepted values: REPLACE_ALL, ENQUEUE, and REPLACE_ENQUEUED.
     *
     * REPLACE_ALL: Immediately begin playback of the stream returned with the Play directive, and
     * replace current and enqueued streams.
     *
     * ENQUEUE: Adds a stream to the end of the current queue.
     *
     * REPLACE_ENQUEUED: Replace all streams in the queue. This does not impact the currently
     * playing stream.
     */
    @SerializedName("playBehavior")
    String playBehavior;
    @SerializedName("audioItem")
    AudioItem audioItem;

    /**
     * A string value used to determine clear queue behavior.
     *
     * Accepted values: CLEAR_ENQUEUED and CLEAR_ALL
     */
    @SerializedName("clearBehavior")
    String clearBehavior;

    @Builder
    @Data
    public static class AudioItem {

        /**
         * Identifies the audioItem.
         */
        @SerializedName("audioItemId")
        String audioItemId;
        @SerializedName("stream")
        AudioStream stream;
    }

    @Builder
    @Data
    public static class AudioStream {

        /**
         * Identifies the location of audio content. If the audio content is a binary audio
         * attachment, the value will be a unique identifier for the content, which is formatted as
         * follows: "cid:". Otherwise the value will be a remote http/https location.
         */
        @SerializedName("url")
        String url;
        /**
         * streamFormat is included in the payload when the Play directive has an associated binary
         * audio attachment. This parameter will not appear if the associated audio is a stream.
         * Accepted Value: AUDIO_MPEG
         */
        @SerializedName("streamFormat")
        String streamFormat;
        /**
         * A timestamp indicating where in the stream the client must start playback. For example,
         * when offsetInMilliseconds is set to 0, this indicates playback of the stream must start
         * at 0, or the start of the stream. Any other value indicates that playback must start from
         * the provided offset.
         */
        @SerializedName("offsetInMilliseconds")
        long offsetInMilliseconds;
        /**
         * The date and time in ISO 8601 format for when the stream becomes invalid.
         */
        @SerializedName("expiryTime")
        String expiryTime;

        /**
         * Contains key/value pairs for progress reports.
         */
        @SerializedName("progressReport")
        ProgressReport progressReport;
        /**
         * An opaque token that represents the current stream.
         */
        @SerializedName("token")
        String token;
        /**
         * An opaque token that represents the expected previous stream.
         */
        @SerializedName("expectedPreviousToken")
        String expectedPreviousToken;
    }

    @Builder
    @Data
    public static class ProgressReport {

        /**
         * Specifies (in milliseconds) when to send the ProgressReportDelayElapsed event to AVS.
         * ProgressReportDelayElapsed must only be sent once at the specified interval. Please note:
         * Some music providers do not require this report. If the report is not required,
         * progressReportDelayInMilliseconds will not appear in the payload.
         */
        @SerializedName("progressReportDelayInMilliseconds")
        long progressReportDelayInMilliseconds;
        /**
         * Specifies (in milliseconds) when to emit a ProgressReportIntervalElapsed event to AVS.
         * ProgressReportIntervalElapsed must be sent periodically at the specified interval. Please
         * note: Some music providers do not require this report. If the report is not required,
         * progressReportIntervalInMilliseconds will not appear in the payload.
         */
        @SerializedName("progressReportIntervalInMilliseconds")
        long progressReportIntervalInMilliseconds;
    }
}
