package demo.aivoice.client.aivs.protocol.payload;

import com.google.gson.annotations.SerializedName;
import lombok.Builder;
import lombok.Data;
import lombok.Getter;

import java.util.List;

@Data
@Builder
public class RenderTemplatePayload extends Payload {

    /**
     * An opaque token provided by Alexa.
     */
    @SerializedName("token")
    String token;
    /**
     * Identifies the template.
     */
    @SerializedName("type")
    String type;
    @SerializedName("title")
    Title title;

    /**
     * The icon/logo for the skill delivering metadata. This is an optional parameter for the
     * content provider and may not be included in the JSON (or may have a null value). The image
     * structure contains information such as url, size, widthPixels and heightPixels. For more
     * information, see image structure below.
     */
    @SerializedName("skillIcon")
    ImageStructure skillIcon;

    // BodyTemplate1
    /**
     * Body text for the card.	string
     */
    @SerializedName("textField")
    String textField;

    // BodyTemplate2
    /**
     * Right-aligned body image.
     */
    @SerializedName("image")
    ImageStructure image;

    // WeatherTemplate
    /**
     * Current temperature for the date requested.
     */
    @SerializedName("currentWeather")
    String currentWeather;
    /**
     * Description of the current weather conditions.
     */
    @SerializedName("description")
    String description;
    /**
     * Image for current weather.
     */
    @SerializedName("currentWeatherIcon")
    ImageStructure currentWeatherIcon;
    /**
     * An object containing temperature and image metadata.
     */
    @SerializedName("highTemperature")
    Temperature highTemperature;
    @SerializedName("lowTemperature")
    Temperature lowTemperature;

    /**
     * Provides weather metadata for X days from the date requested.
     */
    @SerializedName("weatherForecast")
    List<WeatherForecast> weatherForecasts;

    public static class Title {

        /**
         * location in weather template
         */
        @SerializedName("mainTitle")
        String mainTitle;
        /**
         * date in weather template
         */
        @SerializedName("subTitle")
        String subTitle;

        public Title(String mainTitle, String subTitle) {
            this.mainTitle = mainTitle;
            this.subTitle = subTitle;
        }
    }

    public static class Temperature {

        /**
         * High temperature for the date requested.
         */
        @SerializedName("value")
        String value;
        /**
         * Arrow image to render alongside temperature.
         */
        @SerializedName("arrow")
        ImageStructure arrow;

        public Temperature(String value, ImageStructure arrow) {
            this.value = value;
            this.arrow = arrow;
        }
    }

    @Builder
    @Getter
    public static class WeatherForecast {

        /**
         * Representation of weather conditions.
         */
        @SerializedName("image")
        ImageStructure image;
        /**
         * Provides day of the week. For example, "Mon" or "Tue".
         */
        @SerializedName("day")
        String day;
        /**
         * Provides the date. Date follows ABBR_MONTH_DAY format. For example, "Oct 22".
         */
        @SerializedName("date")
        String date;
        /**
         * Provides the high temperature for the associated date.
         */
        @SerializedName("highTemperature")
        String highTemperature;
        /**
         * Provides the low temperature for the associated date.
         */
        @SerializedName("lowTemperature")
        String lowTemperature;
    }

}
