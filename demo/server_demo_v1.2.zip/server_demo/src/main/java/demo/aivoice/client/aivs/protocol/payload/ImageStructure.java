package demo.aivoice.client.aivs.protocol.payload;

import com.google.gson.annotations.SerializedName;
import lombok.Builder;

import java.util.List;

@Builder
public class ImageStructure {

    /**
     * Describes the image. This is an optional parameter for the content provider and may not be
     * included in the JSON.
     */
    @SerializedName("contentDescription")
    String contentDescription;
    /**
     * A list of sources for the same image. It may contain url, size, widthPixels and heightPixels.
     * It's important to note that this is a list and there may be a single or multiple sources.
     */
    @SerializedName("sources")
    List<Source> sources;

    @Builder
    public static class Source {

        /**
         * The image URL. This is always included in the JSON.
         */
        @SerializedName("url")
        String url;
        /**
         * The image URL for night mode assets. These images are optimized for use with dark
         * backgrounds. This is an optional parameter from the service. Click here for additional
         * information.
         */
        @SerializedName("darkBackgroundUrl")
        String darkBackgroundUrl;
        /**
         * The image size as an enumerated value. This is an optional parameter for the content
         * provider and may not be included in the JSON. If widthPixels and/or heightPixels are not
         * provided, render to the specification provided below. Accepted values: X-SMALL, SMALL,
         * MEDIUM,  LARGE and X-LARGE.
         */
        @SerializedName("size")
        String size;
        /**
         * Image width in pixels. This is an optional parameter for the content provider and may not
         * be included in the JSON.
         */
        @SerializedName("widthPixels")
        long widthPixels;
        /**
         * Image height in pixels. This is optional parameter for the content provider and may not
         * be included in the JSON.	long
         */
        @SerializedName("heightPixels")
        long heightPixels;
    }
}
