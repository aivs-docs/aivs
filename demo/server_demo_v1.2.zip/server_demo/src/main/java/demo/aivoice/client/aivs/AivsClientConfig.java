package demo.aivoice.client.aivs;

import com.typesafe.config.Config;
import com.typesafe.config.ConfigFactory;
import lombok.Getter;

@Getter
public class AivsClientConfig {
    private static final String DEFAULT_CONFIG_PATH = "config/aivsclient";
    private static final String CONFIG_NAMESPACE = "com.xiaomi.aivoice.aivsclient";
    private static final String DEPLOY_ENVIRONMENT = "staging";

    private final String appId;
    private final String deviceId;
    private final String signSecret;
    private final String apiKey;
    private final String md5;
    private final String sha256;
    private final String clientId;
    private final String clientSecret;

    public static final AivsClientConfig INSTANCE = new AivsClientConfig();

    private AivsClientConfig() {
        String path = String.format("%s.%s", CONFIG_NAMESPACE, DEPLOY_ENVIRONMENT);
        Config conf = ConfigFactory.load(DEFAULT_CONFIG_PATH).getConfig(path);
        appId = conf.getString("appId");
        deviceId = conf.getString("deviceId");
        signSecret = conf.getString("signSecret");
        apiKey = conf.getString("apiKey");
        md5 = conf.getString("md5_sign");
        sha256 = conf.getString("sha256_sign");
        clientId = conf.getString("clientId");
        clientSecret = conf.getString("clientSecret");
    }
}
