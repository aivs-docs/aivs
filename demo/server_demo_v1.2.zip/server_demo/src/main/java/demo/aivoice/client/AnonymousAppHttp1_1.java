package demo.aivoice.client;

import demo.aivoice.client.aivs.AivsClientConfig;
import demo.aivoice.client.aivs.AivsClient;
import demo.aivoice.client.aivs.AivsHttp1_1Client;
import demo.aivoice.client.aivs.Constant;
import demo.aivoice.client.aivs.protocol.ResponseContent;
import demo.aivoice.client.common.AnonymousClient;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;

import java.util.List;
import java.util.UUID;

public class AnonymousAppHttp1_1 {
    private static final Logger LOGGER = LoggerFactory.getLogger(AnonymousAppHttp1_1.class);

    public static void main(String[] args) throws Exception {
        String appId = AivsClientConfig.INSTANCE.getAppId();
        String deviceId = AivsClientConfig.INSTANCE.getDeviceId();
        //获取用于测试的匿名账号访问token
        String apiKey = AivsClientConfig.INSTANCE.getApiKey();
        AnonymousClient anonymousClient = new AnonymousClient(appId, AivsClientConfig.INSTANCE.getSignSecret());
        String token = anonymousClient.getToken(deviceId, apiKey, AivsClientConfig.INSTANCE.getMd5(), AivsClientConfig.INSTANCE.getSha256());
        LOGGER.info(String.format("anonymous token: %s", token));
        AivsClient client = AivsHttp1_1Client.builder()
                .appId(appId)
                .deviceId(deviceId)
                .token(token)
                .apiKey(apiKey)
                .host(Constant.HOST_STAGING)
                .port(443)
                .build();

        String text = "播放一条新闻";
        List<ResponseContent> responseContents = client
                .textChat(text, UUID.randomUUID().toString(), 113.62, 34.75);

        int index = 0;
        for (ResponseContent responseContent : responseContents) {
            LOGGER.info(String.format("ResponseContent %d: %s", index++,
                    responseContent.toJson()));
        }
    }
}
