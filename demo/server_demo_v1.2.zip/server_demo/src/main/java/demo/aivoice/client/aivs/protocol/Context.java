package demo.aivoice.client.aivs.protocol;

import com.google.gson.annotations.SerializedName;
import demo.aivoice.client.aivs.protocol.payload.Payload;
import lombok.Data;

@Data
public class Context {
    @SerializedName("header")
    Header header;
    @SerializedName("payload")
    Payload payload;

}
