package demo.aivoice.client.utils;

import java.security.MessageDigest;
import java.security.NoSuchAlgorithmException;
import java.security.SecureRandom;

public class DigestUtil {
    private static final String TAG = "DigestUtil";

    public DigestUtil() {
    }

    public static String digest(String type, byte[] byteStr) {
        String digest = null;

        try {
            MessageDigest messageDigest = MessageDigest.getInstance(type);
            messageDigest.reset();
            messageDigest.update(byteStr);
            byte[] byteArray = messageDigest.digest();
            digest = byte2HexFormatted(byteArray);
        } catch (NoSuchAlgorithmException var5) {
            var5.printStackTrace();
        }

        return digest;
    }

    public static String genRandomNum(int len) {
        SecureRandom random = new SecureRandom();
        byte[] randomData = new byte[(len + 1) / 2];
        random.nextBytes(randomData);
        String randomStr = byte2HexFormatted(randomData).replace(":", "");
        return randomStr.substring(0, len);
    }

    public static int adler32(String msg) {
        byte[] data = msg.getBytes();
        int len = data.length;
        int MOD_ADLER = '\ufff1';
        int a = 1;
        int b = 0;

        for(int index = 0; index < len; ++index) {
            a = (a + data[index]) % MOD_ADLER;
            b = (b + a) % MOD_ADLER;
        }

        return b << 16 | a;
    }

    private static String byte2HexFormatted(byte[] arr) {
        StringBuilder str = new StringBuilder(arr.length * 2);

        for(int i = 0; i < arr.length; ++i) {
            String h = Integer.toHexString(arr[i]);
            int l = h.length();
            if (l == 1) {
                h = "0" + h;
            }

            if (l > 2) {
                h = h.substring(l - 2, l);
            }

            str.append(h);
            if (i < arr.length - 1) {
                str.append(':');
            }
        }

        return str.toString();
    }
}
