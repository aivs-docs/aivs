package demo.aivoice.client.aivs.protocol.payload;

import com.google.gson.JsonElement;
import com.google.gson.annotations.SerializedName;
import demo.aivoice.client.utils.Singleton;
import lombok.Data;

/**
 * payload in SpeechRecognizer-Recognize event
 *
 * An empty payload must be sent in ExpectSpeechTimedOut event.
 *
 * @author hanfeng
 */
@Data
public class TextEventPayload extends Payload {

    /**
     * Identifies the language of text to be recognized.
     *
     * Accepted values: zh-CN.
     */
    @SerializedName("language")
    String language;
    /**
     * The text to be recognized.
     *
     * Must encoded in UTF-8
     */
    @SerializedName("text")
    String text;
    @SerializedName("token")
    String token;
    @SerializedName("longitude")
    Double longitude;
    @SerializedName("latitude")
    Double latitude;

    public static TextEventPayload fromJson(JsonElement json) {
        return Singleton.GSON.fromJson(json, TextEventPayload.class);
    }
}
