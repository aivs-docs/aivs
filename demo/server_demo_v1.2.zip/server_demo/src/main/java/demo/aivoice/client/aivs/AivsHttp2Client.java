package demo.aivoice.client.aivs;

import demo.aivoice.client.aivs.protocol.Event;
import demo.aivoice.client.aivs.protocol.Header;
import demo.aivoice.client.aivs.protocol.HeaderName;
import demo.aivoice.client.aivs.protocol.Namespace;
import demo.aivoice.client.aivs.protocol.RequestContent;
import demo.aivoice.client.aivs.protocol.ResponseContent;
import demo.aivoice.client.aivs.protocol.payload.TextEventPayload;
import lombok.Builder;
import org.apache.http.client.utils.URIBuilder;
import org.eclipse.jetty.client.HttpClient;
import org.eclipse.jetty.client.api.ContentResponse;
import org.eclipse.jetty.client.api.Request;
import org.eclipse.jetty.client.util.MultiPartContentProvider;
import org.eclipse.jetty.client.util.StringContentProvider;
import org.eclipse.jetty.http.HttpMethod;
import org.eclipse.jetty.http.HttpStatus;
import org.eclipse.jetty.http2.client.HTTP2Client;
import org.eclipse.jetty.util.component.LifeCycle;
import org.eclipse.jetty.util.component.LifeCycle.Listener;
import org.eclipse.jetty.util.ssl.SslContextFactory;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;

import java.util.Arrays;
import java.util.Collections;
import java.util.List;
import java.util.UUID;

/**
 * AiVS Http2 Client based on jetty
 *
 * need add VM options: -javaagent:<path/to/jetty-alpn-agent.jar>
 */
public class AivsHttp2Client extends AivsClient implements PingSendingHttpClientTransportOverHTTP2.ConnectionListener {

    private static final Logger LOGGER = LoggerFactory.getLogger(AivsHttp2Client.class);

    private String host;
    private int port;
    @Builder.Default
    private int timeout = 5000;

    private String token;
    private String appId;
    private String deviceId;
    private String apiKey;

    private final HttpClient httpClient;
    private final HTTP2Client http2Client;

    @Builder
    public AivsHttp2Client(String host, int port, int timeout, String token, String appId, String deviceId, String apiKey)
            throws Exception {
        this.host = host;
        this.port = port;
        this.timeout = timeout;
        this.token = token;
        this.appId = appId;
        this.deviceId = deviceId;
        this.apiKey = apiKey;

        // init http client
        this.http2Client = new HTTP2Client();
        SslContextFactory sslContextFactory = new SslContextFactory();

        // Sets up an HttpClient that sends HTTP/1.1 requests over an HTTP/2 transport
        httpClient = new HttpClient(new PingSendingHttpClientTransportOverHTTP2(http2Client, this),
                sslContextFactory);
        httpClient.addLifeCycleListener(new Listener() {

            @Override
            public void lifeCycleFailure(LifeCycle arg0, Throwable arg1) {
                LOGGER.error("HttpClient failed", arg1);
                StackTraceElement st[] = Thread.currentThread().getStackTrace();
                LOGGER.info(String.join(System.lineSeparator(), Arrays.toString(st)));
            }

            @Override
            public void lifeCycleStarted(LifeCycle arg0) {
                LOGGER.info("HttpClient started");
            }

            @Override
            public void lifeCycleStarting(LifeCycle arg0) {
                LOGGER.info("HttpClient starting");
            }

            @Override
            public void lifeCycleStopped(LifeCycle arg0) {
                LOGGER.info("HttpClient stopped");
            }

            @Override
            public void lifeCycleStopping(LifeCycle arg0) {
                LOGGER.info("HttpClient stopping");
                StackTraceElement st[] = Thread.currentThread().getStackTrace();
                LOGGER.info(String.join(System.lineSeparator(), Arrays.toString(st)));
            }

        });
        httpClient.start();

    }

    @Override
    public void finalize() throws Exception {
        this.httpClient.stop();
    }


    @Override
    public List<ResponseContent> textChat(String text, String requestId, double longitude, double latitude)
            throws Exception {
        return textChat(text, requestId, longitude, latitude, Constant.APP_ANONYMOUS);
    }

    public List<ResponseContent> textChat(String text, String requestId, double longitude, double latitude, String authType)
            throws Exception {

        // build multi-part body
        Header header = Header.builder()
                .dialogRequestId(UUID.randomUUID().toString())
                .messageId(UUID.randomUUID().toString())
                .namespace(Namespace.TextRecognizer.name())
                .name(HeaderName.TextRecognize.name())
                .build();

        TextEventPayload payload = new TextEventPayload();
        payload.setText(text);

        payload.setLongitude(longitude);
        payload.setLatitude(latitude);

        Event event = Event.builder()
                .header(header)
                .payload(payload.toJsonTree())
                .build();

        RequestContent requestContent = new RequestContent();
        requestContent.setEvent(event);
        // build multi-part
        MultiPartContentProvider multiPart = new MultiPartContentProvider();
        multiPart.addFieldPart("metadata",
                new StringContentProvider(requestContent.toJson()), null);
        multiPart.close();

        // build request
        URIBuilder uri = new URIBuilder();

        uri.setScheme("https");
        uri.setHost(host);
        uri.setPath(Constant.EVENT_PATH);
        uri.setPort(port);
        uri.setParameter("auth_type", "app_anonymous");
        uri.setParameter("app_id", appId);
        uri.setParameter("device_id", deviceId);
        uri.setParameter("api_key", apiKey);
        uri.setParameter("token", token);
        LOGGER.info("http post url:" + uri.toString());
        Request request = httpClient
                .newRequest(uri.build())
                .method(HttpMethod.POST)
                .content(multiPart);

        // sending request
        ContentResponse response = request.send();

        // parsing response
        int statusCode = response.getStatus();
        LOGGER.info("Response code: {}", statusCode);
        LOGGER.info("Response headers: {}", response.getHeaders());

        if (statusCode == HttpStatus.NO_CONTENT_204) {
            LOGGER.info("This response successfully had no content.");
            return Collections.emptyList();
        }
        if (statusCode != HttpStatus.OK_200) {
            LOGGER.error("Receive failure: " + response.getContentAsString());
            return null;
        }

        // 200 success
        String responseStr = response.getContentAsString();

        return buildResponseContents(responseStr);
    }


    @Override
    public void onConnected() {
    }

    @Override
    public void onDisconnected() {
    }

    /**
     * When the application shuts down make sure to clean up the HTTPClient
     */
    public void shutdown() {
        try {
            httpClient.stop();
        } catch (Exception e) {
        }
    }

}
