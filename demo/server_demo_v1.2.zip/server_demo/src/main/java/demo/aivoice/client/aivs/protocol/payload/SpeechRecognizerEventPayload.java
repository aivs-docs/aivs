package demo.aivoice.client.aivs.protocol.payload;

import com.google.gson.JsonElement;
import com.google.gson.annotations.SerializedName;
import demo.aivoice.client.utils.Singleton;
import lombok.Data;

/**
 * payload in SpeechRecognizer-Recognize event
 *
 * An empty payload must be sent in ExpectSpeechTimedOut event.
 *
 * @author hanfeng
 */
@Data
public class SpeechRecognizerEventPayload extends Payload {

    /**
     * Identifies the Automatic Speech Recognition (ASR) profile associated with your product. AVS
     * supports three distinct ASR profiles optimized for user speech from varying distances.
     *
     * Accepted values: CLOSE_TALK, NEAR_FIELD, FAR_FIELD.
     */
    @SerializedName("profile")
    String profile;
    /**
     * Identifies the format of captured audio.
     *
     * Accepted value: AUDIO_L16_RATE_16000_CHANNELS_1.
     */
    @SerializedName("format")
    String format;
    /**
     * Lets Alexa know how an interaction was initiated.
     *
     * This object is required when an interaction is originated by the end user (wake word, tap,
     * push and hold).
     *
     * If initiator is present in an ExpectSpeech directive then it must be returned in the
     * following Recognize event. If initiator is absent from the ExpectSpeech directive, then it
     * should not be included in the following Recognize event.
     */
    @SerializedName("Initiator")
    Initiator initiator;
    /**
     * Specifies, in milliseconds, how long your client should wait for the microphone to open and
     * begin streaming user speech to AVS. If the microphone is not opened within the specified
     * timeout window, then the ExpectSpeechTimedOut event must be sent. The primary use case for
     * this behavior is a PRESS_AND_HOLD implementation.
     */
    @SerializedName("timeoutInMilliseconds")
    long timeoutInMilliseconds;

    @SerializedName("longitude")
    Double longitude;
    @SerializedName("latitude")
    Double latitude;

    public static SpeechRecognizerEventPayload fromJson(JsonElement json) {
        return Singleton.GSON.fromJson(json, SpeechRecognizerEventPayload.class);
    }

}
