package demo.aivoice.client.utils;

import java.lang.reflect.Constructor;
import java.lang.reflect.Field;
import java.lang.reflect.InvocationTargetException;
import java.lang.reflect.Method;

import lombok.Getter;

public class ObjectReflectHelper {

    @Getter
    private Class<?> clazz;
    @Getter
    private Object obj;

    public ObjectReflectHelper(Object obj) {
        this.clazz = obj.getClass();
        this.obj = obj;
    }

    public Method getMethod(String methodName, Class<?>... clzs)
            throws NoSuchMethodException {
        Method method = clazz.getDeclaredMethod(methodName, clzs);
        method.setAccessible(true);
        return method;
    }

    public Object invokeMethod(String methodName, Class<?>[] clzs, Object[] args)
            throws NoSuchMethodException, InvocationTargetException, IllegalAccessException {
        Method method = getMethod(methodName, clzs);
        method.setAccessible(true);
        return method.invoke(obj, args);
    }

    public Object invokeStaticMethod(String methodName, Class<?>[] clzs, Object[] args)
            throws NoSuchMethodException, InvocationTargetException, IllegalAccessException {
        Method method = getMethod(methodName, clzs);
        method.setAccessible(true);
        return method.invoke(null, args);
    }

    protected Field getField(String fieldName)
            throws NoSuchFieldException {
        Field field = clazz.getDeclaredField(fieldName);
        field.setAccessible(true);
        return field;
    }

    public Object getFieldValue(String fieldName)
            throws NoSuchFieldException, IllegalAccessException {
        Field field = getField(fieldName);
        return field.get(obj);
    }

    public void updateFieldValue(String fieldName, Object value)
            throws NoSuchFieldException, IllegalAccessException {
        Field field = getField(fieldName);
        field.set(obj, value);
    }

    public Object getStaticFieldValue(String fieldName)
            throws NoSuchFieldException, IllegalAccessException {
        Field field = getField(fieldName);
        return field.get(clazz);
    }

    public void updateStaticFieldValue(String fieldName, Object value)
            throws NoSuchFieldException, IllegalAccessException {
        Field field = getField(fieldName);
        field.set(clazz, value);
    }

    public Object newInstance(Class<?>[] classes, Object[] args)
            throws NoSuchMethodException, IllegalAccessException, InvocationTargetException, InstantiationException {
        Constructor<?> constructor = clazz.getDeclaredConstructor(classes);
        return constructor.newInstance(args);
    }
}
