package demo.aivoice.client.common;

import demo.aivoice.client.utils.Singleton;
import demo.aivoice.client.aivs.protocol.AnonymousResponse;
import demo.aivoice.client.utils.DigestUtil;
import demo.aivoice.client.utils.SecurityUtil;
import org.apache.commons.codec.binary.Base64;
import org.apache.http.client.methods.CloseableHttpResponse;
import org.apache.http.client.methods.HttpPost;
import org.apache.http.client.methods.HttpRequestBase;
import org.apache.http.client.utils.URIBuilder;
import org.apache.http.impl.client.CloseableHttpClient;
import org.apache.http.impl.client.HttpClientBuilder;

import java.net.URISyntaxException;

/**
 * 首次获取Access_Token/Refresh_Token
 *
 * URL:  /anonymous/app/auth/token
 *
 * method: POST
 *
 * grant_type=app_token & client_id=cid & api_key=akey & device_id=did & md5_sign=md5 & sha256_sign=sha256 & signature=sign1
 * sign1=[NOISE:3][NONCE:8][NOISE:5][SHA1(NONCE+CLIENTID+APIKEY+DEVICEID+SIGNSECRET):40][NOISE:2][Alder32(NONCE+DEVICEID):8][NOISE:3]
 *
 * 返回值: JSON格式    {access_token:atoken,refresh_token:rtoken,expire_in:seconds}
 */
public class AnonymousClient {

    private static final CloseableHttpClient HTTP_CLIENT = HttpClientBuilder.create().build();

    static String HOST_PROD = "account.ai.xiaomi.com";
    static String GET_TOKEN_PATH = "/anonymous/app/auth/token";

    final String clientId;
    final String signSecret;

    public AnonymousClient(String clientId, String signSecret) {
        this.clientId = clientId;
        this.signSecret = signSecret;
    }

    public String getToken(String deviceId, String apiKey, String md5, String sha256) throws Exception {
        String nonce = DigestUtil.genRandomNum(8);
        String apiKeyEncoded = encodeApiKey(nonce, apiKey);

        String signature = getSignature(clientId, signSecret, deviceId, nonce, apiKey);
        System.out.println("signature=" + signature);
        HttpRequestBase httpRequest = buildGetTokenRequest(clientId, deviceId,
                apiKeyEncoded, md5, sha256, signature);

        CloseableHttpResponse httpResponse = HTTP_CLIENT.execute(httpRequest);

        HttpHelper.SimpleHttpResponse simpleResponse = HttpHelper.buildSimpleResponse(httpResponse,
                "getContribution", "testReq");

        AnonymousResponse anonymousResp = Singleton.GSON.fromJson(simpleResponse.getResponse(), AnonymousResponse.class);
        return anonymousResp.getResult().getAccessToken();
    }

    static private String getSignature(String clientId, String signSecret,
                                       String deviceId, String nonce, String apiKey) {

        String sha1 = getSha1(nonce, clientId, apiKey, deviceId, signSecret);
        System.out.println("sha1=" + sha1);
        String alder32 = getAlder32(nonce, deviceId);
        System.out.println("alder32=" + alder32);
        String sign1 = String.format("%s%s%s%s%s%s%s",
                DigestUtil.genRandomNum(3),
                nonce,
                DigestUtil.genRandomNum(5),
                sha1,
                DigestUtil.genRandomNum(2),
                alder32,
                DigestUtil.genRandomNum(3));
        return sign1.toLowerCase().replace(":", "");
    }

    static private String encodeApiKey(String nonce, String apiKey) {
        byte[] apiKeyEnc = SecurityUtil.aesEncrypt((nonce + apiKey).getBytes());
        return Base64.encodeBase64String(apiKeyEnc);
    }

    static private String getSha1(String nonce, String clientId, String apiKey, String deviceId,
                                  String signSecret) {
        String stringToSign = String
                .format("%s%s%s%s%s", nonce, clientId, apiKey, deviceId, signSecret);
        return DigestUtil.digest("SHA1", stringToSign.getBytes());
    }

    static private String getAlder32(String nonce, String deviceId) {
        return String.format("%08x", DigestUtil.adler32(nonce + deviceId));
    }

    private HttpRequestBase buildGetTokenRequest(String clientId, String deviceId, String apiKey,
                                                 String md5, String sha256, String signature) throws URISyntaxException {
        HttpRequestBase httpPost;
        URIBuilder uri = new URIBuilder();

        uri.setScheme("https");
        uri.setHost(HOST_PROD);
        uri.setPath(GET_TOKEN_PATH);
        uri.addParameter("grant_type", "app_token");
        uri.addParameter("client_id", clientId);
        uri.addParameter("api_key", apiKey);
        uri.addParameter("device_id", deviceId);
        uri.addParameter("md5_sign", md5);
        uri.addParameter("sha256_sign", sha256);
        uri.addParameter("signature", signature);

        httpPost = new HttpPost(uri.build());

        return httpPost;
    }

    public static void main(String[] args) throws Exception {
        String clientId = "2882303761517905407";
        String signSecret = "Mb3bIg6MtP0-b_Lnf5By9kMY56mVQNXXRr8Zg95-pfVxGs0UqSsqUtWjyQLmnP0v4wtYFDfhdz4McYxn7fXBJw";

        String deviceId = "testDevice";

        String apiKey = "9w1D5ydld9ioc50kZIkRy1B18G905aC28BrdqgJ9jv0";
        System.out.println("apiKey=" + apiKey);
        String md5 = "e9:e1:fe:df:dc:75:c6:60:ef:73:c2:e5:f2:96:6e:32";
        System.out.println("md5=" + md5);
        String sha256 = "dd:37:5e:ac:49:df:db:3a:cd:17:2f:f6:2f:74:cf:e8:56:78:c3:3b:0e:a6:11:97:ba:d9:fa:94:bd:dd:0c:9d";
        System.out.println("sha256=" + sha256);

        AnonymousClient client = new AnonymousClient(clientId, signSecret);
        String token = client.getToken(deviceId, apiKey, md5, sha256);
        System.out.println("token=" + token);
    }
}
