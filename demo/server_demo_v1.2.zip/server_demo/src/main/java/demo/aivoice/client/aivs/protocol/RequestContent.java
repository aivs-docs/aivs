package demo.aivoice.client.aivs.protocol;

import com.google.gson.annotations.SerializedName;
import demo.aivoice.client.utils.Singleton;
import lombok.Data;

import java.util.List;

@Data
public class RequestContent {

    @SerializedName("context")
    List<Context> contextList;
    @SerializedName("event")
    Event event;

    public static RequestContent fromJson(String json) {
        return Singleton.GSON.fromJson(json, RequestContent.class);
    }

    public String toJson(){
        return Singleton.GSON.toJson(this);
    }

}
