package demo.aivoice.client.utils;

import java.lang.reflect.Proxy;

import org.apache.http.HttpEntity;

public class MultipartFormEntityWrapper {
    public static HttpEntity getWrapper(HttpEntity multipartEntity) {
        return (HttpEntity) (Proxy.newProxyInstance(HttpEntity.class.getClassLoader(),
                new Class[] {HttpEntity.class},
                new MultipartFormEntityInvocationHandler(multipartEntity)));
    }
}
