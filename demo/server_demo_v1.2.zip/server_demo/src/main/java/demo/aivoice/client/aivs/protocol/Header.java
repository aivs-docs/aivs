package demo.aivoice.client.aivs.protocol;

import com.google.gson.annotations.SerializedName;
import demo.aivoice.client.utils.Singleton;
import lombok.Builder;
import lombok.Data;


@Data
@Builder
public class Header {

    @SerializedName("namespace")
    String namespace;
    @SerializedName("name")
    String name;
    /**
     * A unique ID used to represent a specific message.
     */
    @SerializedName("messageId")
    String messageId;
    /**
     * A unique ID used to correlate directives sent in response to a specific Recognize event.
     */
    @SerializedName("dialogRequestId")
    String dialogRequestId;

    public String toJson() {
        return Singleton.GSON.toJson(this);
    }
}
