package demo.aivoice.client.utils;

import java.lang.reflect.InvocationHandler;
import java.lang.reflect.Method;

import org.apache.http.HttpEntity;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;

/**
 * InvocationHandler to walk around the MultipartFormEntity's limitation of content length must less
 * than or equal to 25 *1024 bytes.
 */
public class MultipartFormEntityInvocationHandler implements InvocationHandler {

    private static final Logger LOGGER = LoggerFactory
            .getLogger(MultipartFormEntityInvocationHandler.class);

    private HttpEntity httpEntity;

    public MultipartFormEntityInvocationHandler(HttpEntity httpEntity) {
        this.httpEntity = httpEntity;
    }

    @Override
    public Object invoke(Object proxy, Method method, Object[] objects) throws Throwable {
        LOGGER.info(String.format("Class=%s, method=%s",
                proxy.getClass(),
                method.getName()));
        if ("getContent".equals(method.getName())) {
            long contentLength = httpEntity.getContentLength();
            ObjectReflectHelper reflectHelper = new ObjectReflectHelper(httpEntity);
            try {
                reflectHelper.updateFieldValue("contentLength", 25 * 1024);
                return httpEntity.getContent();
            } finally {
                reflectHelper.updateFieldValue("contentLength", contentLength);
            }
        }
        return method.invoke(httpEntity, objects);
    }
}
