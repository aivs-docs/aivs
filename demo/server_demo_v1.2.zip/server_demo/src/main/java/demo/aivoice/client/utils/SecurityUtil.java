package demo.aivoice.client.utils;

import javax.crypto.Cipher;
import javax.crypto.spec.IvParameterSpec;
import javax.crypto.spec.SecretKeySpec;

public class SecurityUtil {
    private static final String TAG = "SecurityUtil";
    private static final int AES_BLOCK_LENGTH = 16;

    public SecurityUtil() {
    }

    public static byte[] aesEncrypt(byte[] msg) {
        if (msg != null && msg.length != 0) {
            int encLen = ((msg.length - 1) / 16 + 1) * 16;
            byte[] msgWithPadding = new byte[encLen];
            System.arraycopy(msg, 0, msgWithPadding, 0, msg.length);

            for(int i = msg.length; i < encLen; ++i) {
                msgWithPadding[i] = 32;
            }

            byte[] key = new byte[]{-1, -1, 0, 0, 86, -127, 122, 76, -120, -127, -54, -95, 120, 31, -18, -94};
            byte[] iv = new byte[]{-1, -1, -1, 0, -82, -22, 124, 54, 0, -121, -111, -54, -69, 110, -65, 0};

            try {
                byte[] encrypted = encrypt(msgWithPadding, key, iv);
                return encrypted;
            } catch (Exception var6) {
                var6.printStackTrace();
                return null;
            }
        } else {
            return null;
        }
    }

    private static byte[] encrypt(byte[] clean, byte[] key, byte[] iv) throws Exception {
        IvParameterSpec ivParameterSpec = new IvParameterSpec(iv);
        SecretKeySpec secretKeySpec = new SecretKeySpec(key, "AES");
        Cipher cipher = Cipher.getInstance("AES/CBC/NoPadding");
        cipher.init(1, secretKeySpec, ivParameterSpec);
        byte[] encrypted = cipher.doFinal(clean);
        return encrypted;
    }
}