package demo.aivoice.client;

import com.google.gson.JsonObject;
import demo.aivoice.client.aivs.AivsClient;
import demo.aivoice.client.aivs.AivsClientConfig;
import demo.aivoice.client.aivs.AivsHttp1_1Client;
import demo.aivoice.client.aivs.Constant;
import demo.aivoice.client.aivs.protocol.ResponseContent;
import demo.aivoice.client.utils.DeviceOAuthUtil;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;

import java.util.List;
import java.util.UUID;

public class DeviceOAuthText {
    private static final Logger LOGGER = LoggerFactory.getLogger(DeviceOAuthText.class);

    public static void main(String args[]) throws Exception{
        String deviceID = "8ac87cf7e5df4a91af5c89ab5d89853a";
        JsonObject scopeData = new JsonObject();
        scopeData.addProperty("d", deviceID);
        String state = DeviceOAuthUtil.getState(scopeData.toString());
        String scope_data = DeviceOAuthUtil.getBase64ScopeData(deviceID, AivsClientConfig.INSTANCE.getClientId());
        System.out.println(String.format("state=%s", state));
        System.out.println(String.format("scope_data=%s", scope_data));

        AivsClient client = AivsHttp1_1Client.builder()
                .appId(AivsClientConfig.INSTANCE.getClientId())
                .deviceId(deviceID)
                //将通过"设备OAuth授权流程"获取的token，填入该处
                .token("V3_lG0j9g2piKEqbiyAmPpamgz9SCg7d4Y7S-SK1TI6N9IWDddnR2XJ7sy-gI_w-YMV93PsugIy6uqe_ooK_JAyVYzdMqPNqUd223GzczYCdZJbKAtu9WFK6VkHfCQvBZsApufQz_66LnEdLMwlQrbGDSBjNT3uOECu5Qijtn4dubY3MZ32Gr3cjKGOmzQzzShl")
                .host(Constant.HOST_STAGING)
                .port(443)
                .build();

        String text = "播放一条新闻";
        List<ResponseContent> responseContents = client
                .textChat(text, UUID.randomUUID().toString(), 113.62, 34.75, Constant.DEVICE_OAUTH);

        int index = 0;
        for (ResponseContent responseContent : responseContents) {
            LOGGER.info(String.format("ResponseContent %d: %s", index++,
                    responseContent.toJson()));
        }
    }
}